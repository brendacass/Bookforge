(1) Enable module
(2) Enable views_ui module, then go to  /admin/structure/views/view/commerce_cart_form/edit
    > on "Use AJAX" field, change to Yes.
    > Save the view.