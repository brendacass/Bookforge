arrow_down, warning, status, and error icons (and small sizes) used from the Lullabot GPL icon pack
http://www.lullabot.com/articles/free-gpl-icons-lullacons-pack-1